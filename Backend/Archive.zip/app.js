import express from 'express';
import cors from 'cors';
import 'dotenv/config';
import connectdb from './config/mongodb.js';
import connectCloudinary from './config/cloudinary.js';
import userRouter from './routes/userRoute.js';
import productRouter from './routes/productRoute.js';
import cartRouter from './routes/cartRoute.js';
import orderRouter from './routes/orderRoute.js';
import path from 'path';
import { fileURLToPath } from "url";

// ES module __dirname fix
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// App config
const app = express();
const port = process.env.PORT || 3000;

// Connect to DB and Cloudinary
connectdb();
connectCloudinary();

// Middleware
const frontendURL = process.env.FRONTEND_URL || "http://localhost:5173";
app.use(cors({ credentials:true, origin: frontendURL }));
app.use(express.json());

// API routes
app.use('/api/user', userRouter);
app.use('/api/product', productRouter);
app.use('/api/cart', cartRouter);
app.use('/api/order', orderRouter);

// Test route
app.get('/api', (req, res) => {
  res.send("API working");
});

// Serve React build (if build folder exists)
app.use(express.static(path.join(__dirname, "build")));

// Catch-all route for SPA
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "build", "index.html"));
});

// Start server
app.listen(port, "0.0.0.0", () => {
  console.log(`Server started on port: ${port}`);
});
